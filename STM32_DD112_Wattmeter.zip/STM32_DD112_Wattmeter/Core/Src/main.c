/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>          // On importe la librairie la comunication série
#include <string.h>			// On importe la librairie pour manipuler des chaînes de caractères
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define I2C_ADDR 0x3f   // Addresse I2C du PCF8574
#define RS_BIT   0      // Register Select bit
#define EN_BIT   2      // ENable bit
#define BL_BIT   3      // BackLight bit
#define D4_BIT   4      // Data 4 bit
#define D5_BIT   5      // Data 5 bit
#define D6_BIT   6      // Data 6 bit
#define D7_BIT   7      // Data 7 bit
#define LCD_COLS 16     // Nombre de colonnes du LCD
#define LCD_ROWS 2      // Nombre de lignes du LCD
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;
DMA_HandleTypeDef hdma_adc;

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t backlight_state = 1;     // un flag pour le rétroéclairage du LCD
uint16_t adc_data[2];            // Un tableau pour stocker nos 2 valeurs
uint8_t EndOfConversion = 0;     // Un flag pour la conversion
const float d1 = 7.0630954e-2;   // Constante de l'équation issue du datasheet du DD112
const float d2 = 7.3540264e-4;   // Constante de l'équation issue du datasheet du DD112
const float d3 = -6.365981e-7;   // Constante de l'équation issue du datasheet du DD112
const float d4 = 1.0050892e-9;   // Constante de l'équation issue du datasheet du DD112
int PW_Dw = 0;                   // Pour Stocker la valeur de la puissance Directe en Watt
int PW_Rw = 0;                   // Pour Stocker la valeur de la puissance Réfléchie en Watt
const uint16_t Gain = 50;        // Le Gain (à modifier selon la partie amplification du signal)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC_Init(void);
/* USER CODE BEGIN PFP */
void lcd_write_nibble(uint8_t nibble, uint8_t rs);      // Écrire 4 bits sur l'écran LCD (R/W)(Register Select)
void lcd_send_cmd(uint8_t cmd);                         // Envoyer une commande à l'écran LCD
void lcd_send_data(uint8_t data);                       // Envoyer des données à l'écran LCD
void lcd_init();                                        // Initialiser l'écran LCD
void lcd_write_string(char *str);                       // Écrire une chaîne de caractères sur l'écran LCD
void lcd_set_cursor(uint8_t row, uint8_t column);       // Placer le curseur à une position précise sur l'écran LCD
void lcd_clear(void);                                   // Effacer l'écran LCD
void lcd_backlight(uint8_t state);                      // Contrôler le rétroéclairage de l'écran LCD
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc); // Callback de la conversion ADC complète
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// fonction qui retourne la valeur de l'ADC en tension
float convertADCValueToVoltage(int adcValue) {
	return adcValue * 3.3 / 4096;
}

// fonction qui convertie la tension en mV
float convertVoltageToMillivolts(float voltage) {
	return voltage * 1000;
}

// fonction issue du datasheet du DD112 pour convertir le signal en Kw
float calculatePower(float TmV) {
	float PKw = (d1*TmV) + (d2*(TmV*TmV)) + (d3*(TmV*TmV*TmV)) + (d4*(TmV*TmV*TmV*TmV));
	return PKw;
}

// fonction qui affiche les datas dans la com série et update l'écran LCD
void displayData(uint32_t adcValue0, uint32_t adcValue1, float tensionADC0amp, float tensionADC1amp, float tensionADC0mV, float tensionADC1mV, int PW_Dw, int PW_Rw) {
	printf("value channel 0: %lu\r\nvalue channel 1: %lu\r\n", adcValue0, adcValue1);
	printf("tensionADC0amp: %f\r\ntensionADC1amp: %f\r\n", tensionADC0amp, tensionADC1amp);
	printf("tensionADC0mV: %f\r\ntensionADC1mV: %f\r\n", tensionADC0mV, tensionADC1mV);
	printf("PWD: %d\r\nPWR: %d\r\n", PW_Dw, PW_Rw);
	char int_to_textL1[12] = {0};                       // on vide le buffer int_to_textL1
	char int_to_textL2[12] = {0};                       // on vide le buffer int_to_textL2
	sprintf(int_to_textL1, "PWD: %d W", PW_Dw);         // on stock la valeur du premier canal dans le buffer int_to_textL1
	sprintf(int_to_textL2, "PWR: %d W", PW_Rw);         // on stock la valeur du second canal dans le buffer int_to_textL2
	lcd_clear();                                        // on efface l'écran
	lcd_set_cursor(0, 0);                               // on se place ligne 0 colonne 0
	lcd_write_string(int_to_textL1);                    // on affiche ce qu'il y a dans le buffer int_to_textL1
	lcd_set_cursor(1, 0);                               // on se place ligne 1 colonne 0
	lcd_write_string(int_to_textL2);                    // on affiche ce qu'il y a dans le buffer int_to_textL2
}

// fonction qui traite le signal et affiche les datas
void processADCData(uint32_t adc_data_0, uint32_t adc_data_1) {
	// On récupère la tension amplifiée en volts pour les canaux 0 et 1 de l'ADC
	float tensionADC0amp = convertADCValueToVoltage(adc_data_0);
	float tensionADC1amp = convertADCValueToVoltage(adc_data_1);
	// On applique la division par le gain pour obtenir la tension réelle de chaque canaux
	float tensionADC0 = tensionADC0amp / Gain;
	float tensionADC1 = tensionADC1amp / Gain;
	// On convertit les tensions obtenues en millivolts
	float tensionADC0mV = convertVoltageToMillivolts(tensionADC0);
	float tensionADC1mV = convertVoltageToMillivolts(tensionADC1);
	// On calcule la puissance en watts à l'aide de l'équation issue du datasheet du DD112
	PW_Dw = (int)(calculatePower(tensionADC0mV) * 1000);
	PW_Rw = (int)(calculatePower(tensionADC1mV) * 1000);
	// On affiche les données converties et calculées
	displayData(adc_data[0], adc_data[1], tensionADC0amp, tensionADC1amp, tensionADC0mV, tensionADC1mV, PW_Dw, PW_Rw);
}

// fonction qui lit les signaux analogiques
void read_adc_value() {
	// On démarre la conversion ADC avec DMA
	if (HAL_ADC_Start_DMA(&hadc, (uint32_t*)&adc_data, 2) != HAL_OK)
	{
		// On affiche l’erreur
		printf("Il y a eu un problème lors du start de la conversion\r\n");
	}
	// Attendre la fin de la conversion
	while (EndOfConversion == 1)
	{
		EndOfConversion = 0;
	}
	// On arrête la conversion ADC avec DMA
	if (HAL_ADC_Stop_DMA(&hadc) != HAL_OK)
	{
		// On affiche l’erreur
		printf("Il y a eu un problème lors du stop de la conversion\r\n");
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ADC_Init();
  /* USER CODE BEGIN 2 */
  HAL_Delay(500);                        // Délai pour les init()
  printf("STM32 Watt Meter\n\r");        // On écrit dans la com série
  lcd_init();                            // On initialise l'écran
  lcd_backlight(1);                      // On l'allume
  lcd_clear();                           // On efface tout
  lcd_set_cursor(0, 0);                  // On place le curseur ligne 0 colonne 0
  lcd_write_string("STM32 Watt Meter");  // On écrit sur l'écran
  lcd_set_cursor(1, 4);                  // On place le curseur ligne 1 colonne 4
  lcd_write_string("Init OK");           // On écrit sur l'écran
  printf("Init OK\r\n");                 // On écrit dans la com série
  HAL_Delay(2000);                       // Délai pour l'affichage
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  read_adc_value();                           // Appel de la fonction pour lire la valeur de l'ADC
	  processADCData(adc_data[0], adc_data[1]);   // Traitement des données lues des 2 canaux de l'ADC
	  HAL_Delay(1000);                            // Pause d'une seconde pour permettre un délai entre les lectures de l'ADC
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLL_DIV3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = ADC_AUTOWAIT_DISABLE;
  hadc.Init.LowPowerAutoPowerOff = ADC_AUTOPOWEROFF_DISABLE;
  hadc.Init.ChannelsBank = ADC_CHANNELS_BANK_A;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.NbrOfConversion = 2;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  sConfig.SamplingTime = ADC_SAMPLETIME_4CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USER_LED_GPIO_Port, USER_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USER_LED_Pin */
  GPIO_InitStruct.Pin = USER_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USER_LED_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// Fonction qui transmet un caractère via UART et le renvoie.Utilisé pour la sortie standard (printf).
int __io_putchar(int ch) {
    HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, 0xFFFF);  // Pour Envoyer le caractère via UART
    // ITM_SendChar(ch);                 // Option alternative pour envoyer le caractère via ITM
    return ch;
}

// Fonction d'écriture d'une nibble (moitié d'octet) sur l'écran LCD.
// Arguments : nibble - les 4 bits à écrire, rs - le bit registre (0 pour commande, 1 pour données)
void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
    uint8_t data = nibble << D4_BIT;                               	// Déplace la nibble aux bits appropriés
    data |= rs << RS_BIT;                                          	// Configure le bit registre
    data |= backlight_state << BL_BIT;                             	// Inclut l'état du rétroéclairage dans les données
    data |= 1 << EN_BIT;                                           	// Configure le bit enable
    HAL_I2C_Master_Transmit(&hi2c1, I2C_ADDR << 1, &data, 1, 100); 	// Transmet les données à l'écran via I2C
    HAL_Delay(1);                              						// Attente après la transmission
    data &= ~(1 << EN_BIT);                    						// Désactive le bit enable
    HAL_I2C_Master_Transmit(&hi2c1, I2C_ADDR << 1, &data, 1, 100); 	// Retransmet les données sans l'activation
}

// Fonction d' envoi de commande à l'écran LCD.
void lcd_send_cmd(uint8_t cmd) {
    uint8_t upper_nibble = cmd >> 4;  	// Extrait les 4 bits supérieurs de la commande
    uint8_t lower_nibble = cmd & 0x0F;	// Extrait les 4 bits inférieurs de la commande
    lcd_write_nibble(upper_nibble, 0);	// Écrit la moitié supérieure de la commande
    lcd_write_nibble(lower_nibble, 0);	// Écrit la moitié inférieure de la commande
    if (cmd == 0x01 || cmd == 0x02) { 	// Si le CMD est un reset ou un retour à la maison
        HAL_Delay(2);                 	// Attente de 2ms pour compléter la commande
    }
}

// Envoie un octet de données à l'écran LCD.
// Les données sont envoyées en deux parties: le nibble supérieur et le nibble inférieur.
void lcd_send_data(uint8_t data) {
  uint8_t upper_nibble = data >> 4;  	// Extraire les 4 bits supérieurs (le nibble supérieur)
  uint8_t lower_nibble = data & 0x0F; 	// Extraire les 4 bits inférieurs (le nibble inférieur)
  lcd_write_nibble(upper_nibble, 1); 	// Envoyer le nibble supérieur à l'écran LCD avec RS fixé à 1 pour indiquer que ce sont des données
  lcd_write_nibble(lower_nibble, 1); 	// Envoyer le nibble inférieur à l'écran LCD avec RS fixé à 1 pour indiquer que ce sont des données
}


// Fonction d'initialsation de l'écran LCD.
// Ce processus comprend une série de commandes pour configurer l'écran correctement.
void lcd_init() {
  HAL_Delay(50); 				// Attendre 50 ms pour permettre à l'écran de s'allumer
  lcd_write_nibble(0x03, 0); 	// Envoyer la commande d'initialisation 0x03 pour démarrer en mode 4 bits
  HAL_Delay(5); 				// Attendre 5 ms
  lcd_write_nibble(0x03, 0); 	// Répéter la commande d'initialisation 0x03
  HAL_Delay(1); 				// Attendre 1 ms
  lcd_write_nibble(0x03, 0); 	// Répéter à nouveau la commande d'initialisation 0x03 pour assurer la mise en mode 4 bits
  HAL_Delay(1); 				// Attendre 1 ms
  lcd_write_nibble(0x02, 0); 	// Envoyer la commande pour passer en mode 4 bits
  lcd_send_cmd(0x28); 			// Configurer le LCD en mode 4 bits, 2 lignes, 5x7 dots
  lcd_send_cmd(0x0C); 			// Activer l'affichage et désactiver le curseur
  lcd_send_cmd(0x06); 			// Définir le mode d'entrée à incrémentation sans décalage d'affichage
  lcd_send_cmd(0x01); 			// Effacer l'écran
  HAL_Delay(2); 				// Attendre 2 ms pour s'assurer que l'écran est bien effacé
}

// Fonction d'écriture de chaîne de caractères sur l'écran LCD.
// Pn utilise la fonction lcd_send_data pour envoyer chaque caractère.
void lcd_write_string(char *str) {
  while (*str) {
    lcd_send_data(*str++); // Envoyer chaque caractère de la chaîne
  }
}

// Fonction de positionnement du curseur de l'écran LCD sur la ligne et la colonne spécifiées.
void lcd_set_cursor(uint8_t row, uint8_t column) {
    uint8_t address;
    switch (row) {
        case 0:
            address = 0x00; 		// Adresse de mémoire de la première ligne
            break;
        case 1:
            address = 0x40; 		// Adresse de mémoire de la deuxième ligne
            break;
        default:
            address = 0x00; 		// Par défaut : première ligne
    }
    address += column; 				// Ajouter la colonne à l'adresse de base
    lcd_send_cmd(0x80 | address); 	// Envoyer la commande de positionnement de curseur
}


// Fonction d'effacement de l'écran LCD.
void lcd_clear(void) {
    lcd_send_cmd(0x01); // Envoyer la commande d'effacement de l'écran
    HAL_Delay(2); 		// Attendre 2 ms pour s'assurer que l'effacement est complet
}

// Fonction de contrôle d'état du rétroéclairage de l'écran LCD.
void lcd_backlight(uint8_t state) {
    if (state) {
        backlight_state = 1; // Allumer le rétroéclairage
    } else {
        backlight_state = 0; // Éteindre le rétroéclairage
    }
}

// Fonction de callback appelée lorsque la conversion de l'ADC est terminée.
// Cette fonction est déclenchée automatiquement par l'ADC.
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    // Met le flag EndOfConversion à 1 pour indiquer que la conversion est terminée
    EndOfConversion = 1;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
